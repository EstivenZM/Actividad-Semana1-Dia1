numero = int(input("Ingrese un numero: \n"))
residuo= numero % 2


if residuo==0:
    print("Su numero es par")
else:
    print("Su numero es impar")

    