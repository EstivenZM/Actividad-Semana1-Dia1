totalcuenta=int(input("Ingrese el total de su cuenta: \n"))
propina=int(input("Ingrese la propina que desea dejar (10, 15 o 20): \n"))

if propina==10:
    total= (10*totalcuenta)/100
    print("El valor de la propina es de: ",total)
elif propina==15:
    total=(15*totalcuenta)/100
    print("El valor de la propina es de: ",total)
elif propina==20:
    total=(20*totalcuenta)/100
    print("El valor de la propina es de: ",total)
else:
    print("Debes ingresar un numero de 10, 15")
    