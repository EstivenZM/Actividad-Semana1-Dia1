nombre = input("Ingrese su nombre: ")
apellido = input("Ingrese su apellido: ")
correo = input("Ingrese su correo: ")
edad = int(input("Ingrese su edad: "))

if edad >= 18:
    print("Eres mayor de edad")

