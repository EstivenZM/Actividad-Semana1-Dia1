num = int(input("Ingrese un numero: \n"))

if num<=10 and num>=1:
    print("El numero",num," esta dentro del rango")
else:
    print("El numero esta fuera del rango")