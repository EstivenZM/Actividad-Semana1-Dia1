numero = int(input("Ingrese un numero: \n"))

if numero>0:
    print("Su numero es positivo")
else:
    print("Su numero es negativo")