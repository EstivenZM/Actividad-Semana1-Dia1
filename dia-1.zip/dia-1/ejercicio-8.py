peso=int(input("Ingrese su peso: \n"))
altura=float(input("Ingrese su altura: \n"))
alturaelevado=altura*altura
imc=peso/alturaelevado

if imc < 18.5:
    print("Bajo peso")
elif imc > 18.5 and imc <24.9:
    print("Normal")
elif imc > 25 and imc <29.9:
    print("Sobrepeso")
elif imc >= 30:
    print("Obesidad")