contraseñausuario=input("Ingrese su contraseña: \n")

if contraseñausuario=="python123":
    print("Acceso concedido")
else:
    print("Contraseña incorrecta")