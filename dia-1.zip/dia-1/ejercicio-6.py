numsecreto = 7
numusuario= int(input("Advina el numero secreto: \n"))

if numusuario==7:
    print("Adivinaste el numero")
elif numusuario<7:
    print("Tu numero es menor al numero secreto")
else:
    print("Tu numero es mayor al numero secreto")
    