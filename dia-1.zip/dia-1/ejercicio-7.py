num1 = int(input("Ingresa un numero: \n"))
num2 = int(input("Ingresa un numero: \n"))


if num1>num2:
    print("El numero ",num1," es mayor que el ",num2)
elif num1<num2:
    print("El numero ",num2," es mayor que el ",num1)
else:
    print("Ambos numeros son iguales")